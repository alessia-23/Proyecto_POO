package App.Vista;

import javax.swing.*;

public class GestionCitas extends JFrame{
    private JTextField txtCliente;
    private JTextField txtMecanico;
    private JTextField txtHora;
    private JTextField txtServicio;
    private JTextField txtFecha;
    private JTextField txtEstado;
    private JButton btnNuevo;
    private JButton btnMostrar;
    private JButton btnEliminar;
    private JButton btnActualizar;
    private JTable table1;
    private JButton btnImprimir;
    private JPanel panel3;

    public GestionCitas() {
        setTitle("Login");
        setSize(500, 400);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel3);
        setLocationRelativeTo(null);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GestionCitas().setVisible(true);
        });
    }
}
