package App.Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame{
    private JPanel panel2;
    private JTextField txtUsuario;
    private JPasswordField txtPass;
    private JComboBox cmbRol;
    private JButton btnIniciar;
    private JButton btnLimpiar;

    public Login(){
        setTitle("Login");
        setSize(500,400);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panel2);
        setLocationRelativeTo(null);
        //redimensionar imagen


     /*   ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/Imagenes/usuario.png"));
        Image imagenEscalada = iconoOriginal.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon iconoReducido = new ImageIcon(imagenEscalada);
        lblIcono.setIcon(iconoReducido);


  //activar el enter
        getRootPane().setDefaultButton(btnIniciar);
        btnIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = txtUsuario.getText();
                String password = new String(txtPass.getPassword());


                String perfilSeleccionado = cmbRol.getSelectedItem().toString();

                if (user.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor llene todos los campos");
                    return;
                }

                Conexion conexion = new Conexion(); // Crear instancia

                if (conexion.validarUsuario(user, password, perfilSeleccionado)) {
                    JOptionPane.showMessageDialog(Login.this, "¡Login exitoso!");
                    Usuario.setUsuario(user);
                    Usuario.setPerfil(perfilSeleccionado);

                    VistaProducto vistaProducto = new VistaProducto();
                    vistaProducto.setVisible(true);
                    setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(Login.this, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
                }


                txtUser.setText("");
                txtPassword.setText("");
                txtUser.requestFocus();
            }*/
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}
